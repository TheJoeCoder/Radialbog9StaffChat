package com.radialbog9.bungee.staff;

public class PluginInfo {
	public static String pluginName = "StaffChat";
	public static String pluginAuthor = "Radialbog9";
	public static String pluginVersion = "1.1";
}
